const base = {
    host: 'http://localhost:4000/',
    banner: '/api/banner',
    hotHouse: '/api/hotHouse',
    city: '/api/city',
    search: '/api/search',
    houseInfo: '/api/houseInfo',
    comment: '/api/comment',
    recomment: '/api/recommend',
    hotShop: '/api/hotShop',
}

// export const baseUrl = {
//     host: 'http://iwenwiki.com/api/livable/',
// }

export default base;