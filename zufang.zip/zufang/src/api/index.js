import axios from "axios";
import base from "./base";

const api = {
    getBanner() {
        return axios.get(base.banner)
    },

    getHotList() {
        return axios.get(base.hotHouse)
    },

    getCity() {
        return axios.get(base.city)
    },

    search(params) {
        return axios.get(base.search, {params})
    },

    getHouseInfo(params) {
        return axios.get(base.houseInfo, {params})
    },
    getComment(id, page) {
        return axios.get(base.comment, {params:{id,page}})
    },
    getRecommend(page) {
        return axios.get(base.recomment, {params: {page}})
    },
    getHotShop() {
        return axios.get(base.hotShop)
    }
}

export default api;