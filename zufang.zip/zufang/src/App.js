import Routes from './router/index'
export default function App() {
  return (

    <Routes />

  )
}