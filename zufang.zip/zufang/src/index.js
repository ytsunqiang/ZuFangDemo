import React from 'react';
import ReactDOM from 'react-dom/client';
import {
  BrowserRouter
} from "react-router-dom";
import App from './App';
import './common/store/index'
import { Provider } from 'react-redux';
import store from './common/store/index';
import './assets/css/reset.css'
const root = ReactDOM.createRoot(document.getElementById('root'));
root.render( 
  <BrowserRouter>
    <Provider store={store}>
      <App/>
    </Provider>
    
  </BrowserRouter>

);