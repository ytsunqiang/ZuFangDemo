import Life from "../pages/life/Life";
import Shop from "../pages/shop/Shop";
import About from "../pages/about/About";
import Home from "../pages/home/Home";
import Layout from "../pages/Layout";
import { useRoutes } from "react-router-dom";
import City from "../pages/city/City"
import Search from '../pages/search/Search'
import Detail from "../pages/detail/Detail";
import Login from "../pages/login/Login";
import Recommend from "../pages/recommend/Recommend.jsx";
const Routes = () => {

    const routes = [
    
        {
            path: '/',
            element: <Layout/>,
            children:[
                {
                    path: '',
                    element: <Home/>
                },
                {
                    path: 'about',
                    element: <About/>
                },
                {
                    path: 'life',
                    element: <Life/>
                },
                {
                    path: '/shop',
                    element: <Shop/>
                }
            ]
        },
        {
            path: "/city",
            element: <City></City>

        },
        {
            path: '/search',
            element: <Search/>
        },
        {
            path: '/detail/:id',
            element: <Detail/>
        },
        {
            path: '/login',
            element: <Login/>
        },
        {
            path: '/recommend',
            element: <Recommend/>

        }
    ]
    
    return useRoutes(routes)
}




export default Routes;