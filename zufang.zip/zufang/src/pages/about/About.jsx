
import style from './style.module.scss'
import {UserCircleOutline, SetOutline, CouponOutline} from 'antd-mobile-icons'
import { useNavigate } from 'react-router-dom'
export default function About() {
    const nav = useNavigate()
    return (
        <div>
            <div className={style.header}>
                
                <SetOutline className={style.set} />
                <UserCircleOutline />
            </div>

            <div className={style.container}>
                <div className={style.item}>
                    <CouponOutline className={style.icon} />
                    <p>优惠券</p>
                </div>
                <div className={style.item}>
                    <CouponOutline className={style.icon} />
                    <p>优惠券</p>
                </div>
                <div className={style.item}>
                    <CouponOutline className={style.icon} />
                    <p>优惠券</p>
                </div>
                <div className={style.item}>
                    <CouponOutline className={style.icon} />
                    <p>优惠券</p>
                </div>
                <div className={style.item}>
                    <CouponOutline className={style.icon} />
                    <p>优惠券</p>
                </div>
                <div className={style.item}>
                    <CouponOutline className={style.icon} />
                    <p>优惠券</p>
                </div>
                <div className={style.item} onClick={()=>{nav("/recommend")}}>
                    <CouponOutline className={style.icon} />
                    <p>评价</p>
                </div>
                <div className={style.item}>
                    <CouponOutline className={style.icon} />
                    <p>优惠券</p>
                </div>
            </div>

            <h3>宜居管家</h3>

            <div className={style.container}>
                <div className={style.item}>
                    <CouponOutline className={style.icon} />
                    <p>优惠券</p>
                </div>
                <div className={style.item}>
                    <CouponOutline className={style.icon} />
                    <p>优惠券</p>
                </div>
                <div className={style.item}>
                    <CouponOutline className={style.icon} />
                    <p>优惠券</p>
                </div>
                <div className={style.item}>
                    <CouponOutline className={style.icon} />
                    <p>优惠券</p>
                </div>
                <div className={style.item}>
                    <CouponOutline className={style.icon} />
                    <p>优惠券</p>
                </div>
                <div className={style.item}>
                    <CouponOutline className={style.icon} />
                    <p>优惠券</p>
                </div>
                <div className={style.item}>
                    <CouponOutline className={style.icon} />
                    <p>优惠券</p>
                </div>
                <div className={style.item}>
                    <CouponOutline className={style.icon} />
                    <p>优惠券</p>
                </div>
            </div>
        </div>
    )
}