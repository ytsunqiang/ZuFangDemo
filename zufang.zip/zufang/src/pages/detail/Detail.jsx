
import { useParams } from "react-router-dom"
import { useEffect, useState } from "react"
import api from "../../api"
import Nav from "../../common/Nav"
import AntdSwiper from "../antdSwiper/AntdSwiper"
import style from "./style.module.scss"
import { Rate,Tabs,List, InfiniteScroll } from "antd-mobile"
import { useNavigate } from "react-router-dom"
import { useSelector } from "react-redux"

const Detail = () => {

    const param = useParams()
    const [info, setInfo] = useState({})
    const [banner, setBanner] = useState([])
    const [common, setCommon] = useState([])
    const [hasMore, setHasMore] = useState(false)
    const [page, setPage] = useState(0)

    var a = (localStorage.getItem("collect") === "{}") ?  [] : JSON.parse(localStorage.getItem("collect"))
    let array = new Set(a)


    const [collect, setCollect] = useState(false)

    const isLogin = useSelector(store => {
        return store.user.isLogin
    })

    const navigate = useNavigate()
    function formatPhone(num) {

        return num.substring(0,3) + "****" + num.substring(7)
    }

    function getHouseInfo() {
        api.getHouseInfo({id: param.id}).then((res)=>{
            setInfo(res.data.info)

            setBanner(res.data.info.imageUrl)
        })
    }

    function getCommentInfo() {
        console.log(page);
        api.getComment(param.id, page).then((res)=>{
            setCommon([...common, ...res.data.list])

            setPage(page+1)
            setHasMore(res.data.list.length > 0)
        })
    }

    function gotoLogin() {
        
        if (isLogin) {
            if (collect) {
                array.delete(param.id)
            } else {
                array.add(param.id)
            }
            localStorage.setItem("collect", JSON.stringify([...array]))
            setCollect(!collect)
        } else {
            navigate('/login')
        }
    }

    useEffect(()=>{
        setCollect(array.has(param.id))
        getHouseInfo()
        getCommentInfo()
    },[])

    return (
        <div className={style.box}>
            <Nav>详情页</Nav>
            接收到id{param.id}

            <AntdSwiper arr={banner}></AntdSwiper>
            <Tabs>
                <Tabs.Tab title='房源信息' key='source'>
                    
                    <div className={style.shadowBox}>


                        <div>
                            <p className={style.redP}>{info.price}/月</p>
                            <p>租金</p>
                        </div>

                        <div>
                            <p className={style.redP}>{info.huxing}</p>
                            <p>户型</p>
                        </div>

                        <div>
                            <p className={style.redP}>{info.area}m</p>
                            <p>面积</p>
                        </div>

                    </div>
                    <div className={style.detailInfo}>
                        <p>名称：{info.title}</p>
                        <p>装修：{info.zhuangxiu}</p>
                        <p>楼层：{info.floor}</p>
                        <p>朝向：{info.chaoxiang}</p>
                    </div>


                </Tabs.Tab>
                <Tabs.Tab title='评价信息' key='evaluate'>
                <div className={style.detailInfo} >
                <List>
                    {
                        
                        common.map((item) => {

                            return (
                                <List.Item key={item.id} className={style.lineBox}>

                                    <p>电话：{formatPhone(item.tel)}</p>
                                    <div>星星：<Rate readOnly value={item.start}></Rate></div>
                                    <p>评价内容：{item.content}</p>
                                </List.Item>
                               
                            )
                        })
                    }
                     </List>
                        <InfiniteScroll loadMore={getCommentInfo} hasMore={hasMore}></InfiniteScroll>
                    </div>
                </Tabs.Tab>
            </Tabs>
            
            <div className={style.bottom}>
                <div onClick={gotoLogin}>{collect ? "已收藏" : "收藏"}</div>
                <div>购买</div>
            </div>
        </div>
    )

}

export default Detail