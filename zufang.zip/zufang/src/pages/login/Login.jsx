import style from "./style.module.scss"
import { setUser } from "../../common/store/user"
import { useDispatch } from "react-redux"
import { useEffect, useRef, useState } from "react"
import { Toast } from "antd-mobile"
import { useNavigate } from "react-router-dom"
const Login = () => {
    const ref = useRef()
    const dispatch = useDispatch()
    const nav = useNavigate()
    useEffect(()=>{
        ref.current.focus()
    },[])
    const [userName, setUserName] = useState("")

    const [pwd, setPwd] = useState("")

    function changeUserName(e) {

        setUserName(e.target.value)
    }

    function changePwd(e) {
        setPwd(e.target.value)
    }

    function submit() {
        if (pwd === "123" && userName === "123") {
            Toast.show("登录成功")

            const user = {
                token: "fdafjlkdfjafkjal;",
                userName: "sq",
                isLogin: true
            }

            dispatch(setUser(user))
            nav(-1)

        } else {
            Toast.show("用户名密码错误")
        }
    }

    return (
        <div className={style.container}>
            <div className={style.background}>宜家</div>
            <div className={style.loginBox}>
                <input ref={ref} value={userName} onChange={changeUserName} placeholder="请输入账号" type="text" />
                <input type="password" placeholder="请输入密码" value={pwd} onChange={changePwd} />
                <div className={style.submit} onClick={submit}>登录</div>
            </div>
        </div>
        
    )
}
export default Login