

import Nav from "../../common/Nav";
import style from "./style.module.scss"
import React, { useState, useEffect } from "react";
import api from "../../api";
import { IndexBar, List } from 'antd-mobile'
import { useSelector, useDispatch } from "react-redux";
import { change } from "../../common/store/city";

const City = () => {

    function cityContent(arr) {
        if (!arr || arr.length === 0) {
            return (<div></div>)
        }
        return arr.map((item)=>{
            return (
                <div onClick={selectCity.bind(null, item.name)} className={style.cityName} key={item.id}>{item.name}</div>
            )
        })
    }

    let city = useSelector((store)=>store.city.cityName)
    const dis = useDispatch()
    function selectCity(cityName) {
        dis(change(cityName))
    }

    const [hotCity, setHotCity] = useState([])
    const [cityList, setCityList] = useState([])
    
    
    useEffect(()=>{

        api.getCity()
        .then((res)=>{
            const dict = res.data.city.indexCitys
            setHotCity(dict.hot)
            // setCurrentCity(dict.pos)
            let array = []
            for (const key in dict) {
                if (key === 'hot' || key === "pos") {
                    continue
                }
                array.push({
                    title: key,
                    items: dict[key]
                })
            }
            setCityList(array)            

        })
        

    }, [])
    return (
        <div>
            <Nav>城市选择</Nav>
            {/* 当前城市 */}
            <div>
                <div className={style.title}>当前城市</div>
                
                

                <div className={style.cityName} key={10}>{city}</div>
            </div>
            {/* 热门城市 */}
            <div>
                <div className={style.title}>热门城市</div>

                {
                    cityContent(hotCity)
                }
            </div>

            {
                <div style={{height:window.innerHeight-200, marginTop:'10px'}}>
                <IndexBar>
                  {cityList.map(group => {
                    const { title, items } = group
                 
                    return (
                      <IndexBar.Panel
                        index={title}
                        title={`${title}`}
                        key={`标题${title}`}
                        className={style.sectionHeader}
                      >
                        <List>
                          {items.map((item) => (
                            <List.Item onClick={selectCity.bind(null, item.name)} key={item.id}>{item.name}</List.Item>
                          ))}
                        </List>
                      </IndexBar.Panel>
                    )
                  })}
                </IndexBar>
              </div>
            }

        </div>
    )
}

export default City;