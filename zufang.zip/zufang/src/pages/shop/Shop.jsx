
import style from './style.module.scss'
import { useNavigate } from 'react-router-dom'
import AntdSwiper from '../antdSwiper/AntdSwiper'
import { useEffect, useState } from 'react'
import api from '../../api'
import List from './list/List'

export default function Shop() {

    const nav = useNavigate()
    const [banner, setBanner] = useState([])
    const [hotShop, setHotShop] = useState([])
    function goSearch() {
        nav('/search')
    }


    useEffect(()=>{
        api.getBanner()
        .then(res=>{
            setBanner(res.data.data)
        })

        api.getHotShop()
        .then((res)=>{
            setHotShop(res.data.list)
        })

    },[])

    return (
        <div>

            {/* header */}
            <div className={style.header}>

                <div className={style.center} onClick={goSearch}>
                    {/* <Search /> */}
                </div>

                <div className={style.shop}>购物车</div>

            </div>
            {/* 轮播图 */}
            <AntdSwiper arr={banner}></AntdSwiper>

            <div className={style.content}>
                <div className={style.item}>新品上市</div>
                <div className={style.item}>二手商城</div>
            </div>

            <List title="热销单品" arr={hotShop}>

            </List>
            <List title="家庭常用" arr={hotShop}>

            </List>
        </div>
    )
}