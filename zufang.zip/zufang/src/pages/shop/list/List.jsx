
import style from "./style.module.scss"

export default function List(props) {

    return (
        <div>
            <h3>{props.title}</h3>

                <ul className={style.container}>
                    {
                        props.arr.map((item)=>{
                            return (
                                <li key={item.id}>
                                    <div className={style.item}>
                                        <img src={item.img} alt="" />
                                        <p>{item.title}</p>
                                    </div>
                                </li>
                            )
                        })
                    }
                </ul>
            </div>

    )
}