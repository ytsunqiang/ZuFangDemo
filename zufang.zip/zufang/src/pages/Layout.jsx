import React from "react"
import { Outlet } from "react-router-dom"
import Footer from "../common/Footer"


export default function Layout() {

    return (
        <div>
            
            <Outlet>ccc</Outlet>
            <div style={{height: '100px'}}>
                <Footer />
            </div>
            
        </div>
    )
}