export default function Life() {
    return (
        <div>Life</div>
    )
}