import Nav from "../../common/Nav"
import { useSelector } from "react-redux"
import style from './style.module.scss'
import { useEffect, useState } from "react"
import api from "../../api"
import { InfiniteScroll, Rate } from "antd-mobile"

const Recommend = () => {

    const city = useSelector((store) => store.city.cityName)
    const user = useSelector((store) => store.user.userName)
    const [data, setData] = useState([])
    const [page, setPage] = useState(0)
    const [value, setValue] = useState("")
    let star = 0

    const [current, setcurrent] = useState(-1)

    function onChange(e) {
        setValue(e.target.value)
    }

    function getRecommend() {
        api.getRecommend(page)
        .then((res)=>{
            setPage(page + 1)
            
            setData([...data, ...res.data.list])
        })
    }

    function recommend(index) {
        
        setcurrent(index)
    }

    function cancel() {
        setcurrent(-1)
        setValue("")
    }

    function submit(index) {
        console.log(star, index, value);
        data[index].recommend = true
        setData([...data])
        setcurrent(-1)
        setValue("")
    }

    useEffect(()=>{
         getRecommend()
    },[])

    return (
        <div>
            <Nav>房源评论</Nav>
            <p>用户名：{user}</p>
            <p>所在城市：{city}</p>
            <ul>

                {
                    data.map((item, index)=>{
                        return(
                        <li key={item.id}>
                            <div className={style.listItem}>
                                <div className={style.img}>
                                    <img src={item.imageUrl} alt="" />
                                    <p>current:{page} id: {item.id}</p>
                                </div>
        
                                <div className={style.info}>
                                    <p>标题：{item.content}</p>
                                    <p>户型：{item.huxing} </p>
                                    <p>价格:{item.price}/月 </p>
                                </div>

                                <div className={item.recommend ? style.button2 : style.button} onClick={recommend.bind(null, index)}>
                                    {item.recommend ? "已评论" : "评论"}
                                </div>

                            </div>
                            {
                            item.id === current ? 
                            <div>
                                <textarea value={value} onChange={onChange} name="" id="" placeholder="请输入评论" cols="30" rows="3"></textarea>
                                <Rate onChange={val => {star = val}} />
                                <button onClick={submit.bind(null, index)}>确定</button>
                                <button onClick={cancel.bind(null, index)}>取消</button>
                            </div>
                            

                            : ""
                        }
                        </li>)


                    })
                }

                
            </ul>
            <InfiniteScroll loadMore={getRecommend} hasMore={true} />
        </div>
    )

}
export default Recommend