
import { Swiper } from "antd-mobile"
import PropTypes from 'prop-types'

export default function AntdSwiper(prop) {

    return (
        <div>
            <Swiper loop autoplay defaultIndex={0} indicator={(total, current) => (
              <div style={{position:"absolute", bottom:"0.1rem", right:"0.1rem", color: "white"}}>
                {`${current + 1} / ${total}`}
              </div>
            )}>
            {
                prop.arr.length? prop.arr.map((item, index)=>{
                    return (
                        <Swiper.Item key={index}>
                        <img src={item.imageUrl || item} width='100%' alt=""></img>
                    </Swiper.Item>
                    )
                }) : <Swiper.Item></Swiper.Item>
            }
            
            </Swiper>
        </div>
    )
}

AntdSwiper.propTypes = {
    arr: PropTypes.array.isRequired
}