
import style from './style.module.scss'
import Nav from '../../common/Nav';
import HeaderSearch from '../../common/Search';
import api from '../../api';
import HotList from '../home/hotList/HotList';
import React from 'react';
// import { useSelector } from 'react-redux';

class Search extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            list: [],
            page: 0
        };
    }
    // city = useSelector(store=>store.city.cityName)
    loading = false

    search = (value, page=0) => {
        const param = {
            city: "北京",
            value,
            page
        }
        console.log("param",param);
        api.search(param).then((res)=>{
            this.setState({list: [...this.state.list, ...res.data.list], page: this.state.page + 1}, ()=>{
                this.loading = false
                console.log("ddd", this.state.page, this);    
                window.addEventListener("scroll", this.didScroll)
            })    
        })
    }

    componentDidMount() {
        // window.addEventListener("scroll", this.didScroll)
        // this.search("")
    }

    didScroll = () => {
        const scrollH = document.scrollingElement.scrollTop;
        const bodyH = document.body.clientHeight;
        const viewH = window.innerHeight;
        if (!this.loading && viewH + scrollH + 100 >= bodyH) {
            window.removeEventListener("scroll", this.didScroll)
            this.loadMore()
        }
    }

    loadMore = () => {
        this.loading = true
        
        this.search(this.val, this.state.page)
    }

    onKeyUp = (value, keyCode) => {
        if (keyCode === 13) {
            // val = value
            this.search(value)
        }
    } 

    render() {
        return (
            <div className={style.search}>
                <Nav>
                    <div className={style.searchHeader}>
                        <HeaderSearch onKeyUp={this.onKeyUp}>
                        
                        </HeaderSearch>
                    </div>
                </Nav>
                <HotList arr={this.state.list}></HotList>
            </div>
        )
    }
}

export default Search;