
import style from './style.module.scss'
import Nav from '../../common/Nav';
import HeaderSearch from '../../common/Search';
import { useEffect, useState } from 'react';
import api from '../../api';
import HotList from '../home/hotList/HotList';
import { useSelector } from 'react-redux';

const Search = ()=>{

    const city = useSelector(store=>store.city.cityName)
    const [list, setList] = useState([])
    const [page, setPage] = useState(0)

    let val = ""

    async function search(value, page=0) {
        const param = {
            city: city,
            value,
            page: page + 1
        }
        let res = await api.search(param)

        let num = page + 1
            
        setList([...list, ...res.data.list]);
        setPage(num)
    }

    useEffect(()=>{
        console.log("useEffect", city);
        // search("")
        window.addEventListener("scroll", didScroll)
        console.log("page", page);
        
    }, [list])

    function didScroll() {
        const scrollH = document.scrollingElement.scrollTop;
        const bodyH = document.body.clientHeight;
        const viewH = window.innerHeight;
        if (viewH + scrollH + 100 >= bodyH) {
            loadMore()
        }
    }

    function loadMore (){
        window.removeEventListener("scroll", didScroll)
        search(val, page)
    }

    function onKeyUp(value, keyCode) {
        if (keyCode === 13) {
            val = value
            search(value)
        }
    }

    return (
        <div className={style.search}>
            <Nav>
                <div className={style.searchHeader}>
                    <HeaderSearch onKeyUp={onKeyUp}>
                    
                    </HeaderSearch>
                </div>
            </Nav>
            <HotList arr={list}></HotList>
        </div>
    )
}

export default Search;