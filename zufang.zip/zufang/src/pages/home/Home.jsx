import style from './style.module.css'

import { DownOutline } from 'antd-mobile-icons'
import AntdSwiper from '../antdSwiper/AntdSwiper'
import { NavLink } from 'react-router-dom'
import { useEffect, useState } from 'react'
import api from '../../api'
import HotList from './hotList/HotList'
import { useNavigate } from 'react-router-dom'
import { useSelector } from 'react-redux'

export default function Home() {

    const [banner, setBanner] = useState([])
    const [hotList, setHotList] = useState([])


    const city = useSelector(store=>store.city.cityName) 

    const nav = useNavigate()
    useEffect(() => {
        api.getBanner()
        .then(res=>{
            setBanner(res.data.data)
        })

        api.getHotList()
        .then(res=> {
            setHotList(res.data.list)
        })

    },[])

    function goSearch() {
        nav('/search')
    }

    return (
        <div>
            {/* header */}
            <div className={style.header}>
                <div className={style.location}>
                    <NavLink to='/city'>
                        {city}<DownOutline />
                    </NavLink>
                </div>

                <div className={style.center} onClick={goSearch}>
                    {/* <Search /> */}
                </div>

                <div className={style.shop}>购物车</div>

            </div>
            {/* 轮播图 */}
            <AntdSwiper arr={banner}></AntdSwiper>

            <div className={style.content}>
                <div className={style.item}>找舍友</div>
                <div className={style.item}>宜居社区</div>
            </div>

            <HotList arr={hotList} />

        </div>

    )
}