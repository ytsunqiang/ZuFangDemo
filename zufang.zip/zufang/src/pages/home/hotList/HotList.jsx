

import ProTypes from 'prop-types'
import style from './style.module.scss'
import { Grid } from 'antd-mobile'
import { useNavigate } from 'react-router-dom';

export default function HotList(prop) {

    const nav = useNavigate()
    function onClick(props) {
        nav("/detail/"+props)
    }

    return (
        <div>
            <h3>热门房源</h3>
            {
                prop.arr.map(item=>{
                    
                    return <div key={item.id} className={style.list} onClick={onClick.bind(null, item.id)}>
                             <img src={item.imageUrl} alt="" />
                             <div className={style.detail}>

                                <Grid columns={3}>

                                    <Grid.Item span={2}>
                                        <div className={style.col}>
                                            <p>
                                                {item.adress}
                                            </p>
                                            <p>
                                                {item.floor?<span>楼层：{item.floor}</span>:""}
                                                {item.huxing} 
                                                {item.area}m
                                                </p>
                                        </div>
                                    </Grid.Item>
                                    <Grid.Item>
                                        <div className={style.col1}>
                                            <span className={style.typeButton}>
                                                {item.type}
                                            </span>
                                            <p className={style.price}>{item.price}/月</p>    
                                        </div>
                                        
                                    </Grid.Item>
                                </Grid>

                             </div>
                           </div>
                })
            }

            <div>

            </div>
        </div>        
    )
}

HotList.ProTypes = {
    arr: ProTypes.array.isRequired
}