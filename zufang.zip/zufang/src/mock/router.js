const Mock = require('mockjs')

const express = require('express')
const router = express.Router();

const city = require('./data.json')

router.get('/',(req, res)=>{
    res.send('hello')
})
// http://iwenwiki.com/api/livable/banner/banner1.png
router.get('/banner',(req, res)=>{
    const data = Mock.mock({
            status: 200,
            msg: 'ok',
            "data|3": [
                {
                    "id|+1":1,
                    "imageUrl|+1": ["http://iwenwiki.com/api/livable/banner/banner1.png", 'http://iwenwiki.com/api/livable/banner/banner2.png', "http://iwenwiki.com/api/livable/banner/banner3.png"],
                    "herf|+1": ['www.baidu.com', 'www.jd.com', 'www.sina.com']
                }
            ]
        })
    res.send(data)
        }
    )


router.get("/city", (req, res) => {

    res.send({
        status: 200,
        msg: "ok",
        city
    })
})

router.get('/hotHouse', (req, res)=>{
    const city = req.query.city || '北京'
    const data = Mock.mock({
        status: 200,
        msg:"ok",
        "list|6": [{
            "id|+1":100,
            "huxing|1":["两室一厅", "三室一厅", "三室一厅"],
            "area|50-100":60,
            "type|1": ["整租", "合租"],
            "price|3000-10000": 5000,
            "adress":city + ' @cword(5,8)',
            "imageUrl|+1":['http://iwenwiki.com/api/livable/details/1.jpg', 'http://iwenwiki.com/api/livable/details/2.jpg', 'http://iwenwiki.com/api/livable/details/3.jpg', "http://iwenwiki.com/api/livable/details/4.jpg", "http://iwenwiki.com/api/livable/details/5.jpg", "http://iwenwiki.com/api/livable/details/6.jpg"]
        }]

    })

    res.send(data)

})

router.get('/search', (req, res)=>{
    const city = req.query.city || ""
    const value = req.query.value || ""
    const page = req.query.page || 0
    const flag = page * 100 
    const data = Mock.mock({
        status: 200,
        msg:"ok",
        "list|10": [{
            "id|+1":flag,
            "huxing|1":["两室一厅", "三室一厅", "三室一厅"],
            "area|50-100":60,
            "zong|5-10":5,
            "cur|1-10":5,
            "type|1": ["整租", "合租"],
            floor: function () {
                if (this.zong >= this.cur) {
                    return this.cur + '/' + this.zong
                } else {
                    return this.zong + '/' + this.cur
                }
            },
            "price|3000-10000": 5000,
            "adress":city + value + ' @cword(5,8)',
            "imageUrl|1":['http://iwenwiki.com/api/livable/details/1.jpg', 'http://iwenwiki.com/api/livable/details/2.jpg', 'http://iwenwiki.com/api/livable/details/3.jpg', "http://iwenwiki.com/api/livable/details/4.jpg", "http://iwenwiki.com/api/livable/details/5.jpg", "http://iwenwiki.com/api/livable/details/6.jpg"]
        }]
    })

    res.send(data)

})

router.get('/houseInfo', (req, res)=>{
    const data = Mock.mock({
        status: 200,
        msg:"ok",
        "info": {
            "title":req.query.id + ' @cword(5,8)',
            "price|3000-10000": 5000,
            "huxing|1":["两室一厅", "三室一厅", "三室一厅"],
            "area|50-100":60,
            "zong|5-10":5,
            "cur|1-10":5,
            "type|1": ["整租", "合租"],
            floor: function () {
                if (this.zong >= this.cur) {
                    return this.cur + '/' + this.zong
                } else {
                    return this.zong + '/' + this.cur
                }
            },
            "chaoxiang|1":["东","南","西","北"],
            "zhuangxiu|1":["简装","精装","毛坯"],
            "year|1985-2020": 1988,
            "imageUrl":['http://iwenwiki.com/api/livable/details/1.jpg', 'http://iwenwiki.com/api/livable/details/2.jpg', 'http://iwenwiki.com/api/livable/details/3.jpg', "http://iwenwiki.com/api/livable/details/4.jpg", "http://iwenwiki.com/api/livable/details/5.jpg", "http://iwenwiki.com/api/livable/details/6.jpg"]
        }

    })

    res.send(data)

})

router.get('/comment', (req, res)=>{
    const page = req.query.page
    const data = Mock.mock({
        status: 200,
        msg:"ok",
        "list|6": [{
            "id|+1":page * 10,
            tel:/1\d{10}/,
            'start|1-5':1,
            "content":' @cword(25,48)',
            "imageUrl|+1":['http://iwenwiki.com/api/livable/details/1.jpg', 'http://iwenwiki.com/api/livable/details/2.jpg', 'http://iwenwiki.com/api/livable/details/3.jpg', "http://iwenwiki.com/api/livable/details/4.jpg", "http://iwenwiki.com/api/livable/details/5.jpg", "http://iwenwiki.com/api/livable/details/6.jpg"]
        }]

    })

    res.send(data)

})

router.get('/recommend', (req, res)=>{
    const page = req.query.page
    const data = Mock.mock({
        status: 200,
        msg:"ok",
        "list|6": [{
            "id|+1":page * 10,
            "content":' @cword(5,48)',
            "price|3000-10000": 5000,
            'recommend|1':[true, false], 
            "huxing|1":["两室一厅", "三室一厅", "三室一厅"],
            "imageUrl|1":['http://iwenwiki.com/api/livable/details/1.jpg', 'http://iwenwiki.com/api/livable/details/2.jpg', 'http://iwenwiki.com/api/livable/details/3.jpg', "http://iwenwiki.com/api/livable/details/4.jpg", "http://iwenwiki.com/api/livable/details/5.jpg", "http://iwenwiki.com/api/livable/details/6.jpg"]
        }]

    })

    res.send(data)

})

router.get('/hotShop', (req, res)=>{
    const data = Mock.mock({
        status: 200,
        msg:"ok",
        "list|4": [{
            "id|+1":10,
            "title": "储物柜",
            "img":'http://iwenwiki.com/api/livable/homehot/img_chuwugui.png'
        }]

    })

    res.send(data)

})

module.exports = router