
const router = require('./router')
const express = require('express')
const app = express()
app.use("/", router)

// app.get('/',(req, res) => {
//     const data = Mock.mock({

//         msg: 'ok',
//         "list|10": [{
//             'id|+1':1,
//             info: "hello mockjs",
//             "string|1-10": "★",
//             "object|2": {
//                 "310000": "上海市",
//                 "320000": "江苏省",
//                 "330000": "浙江省",
//                 "340000": "安徽省"
//               }
//         }],
        
//     })
//     res.send(data)
// })

app.listen(4000, () => {
    console.log(4000);
})
