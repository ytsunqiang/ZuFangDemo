import { configureStore } from "@reduxjs/toolkit";

import citySlice from './city'
import userSlice from './user'

const store = configureStore({
    reducer: {
        city: citySlice,
        user: userSlice
    }
})

export default store