import { createSlice } from "@reduxjs/toolkit";

const userSlice = createSlice({
    name: 'user',
    initialState: {
        userName: "",
        token: "",
        isLogin: false
    },
    reducers: {
        setUser:(state, action) => {
            state = action.payload
            return state 
        },
        deleteUser:state => {
            state.userName = ""
            state.token = ""
            state.isLogin = false
        }
    }
})

export const {setUser, deleteUser} = userSlice.actions

export default userSlice.reducer