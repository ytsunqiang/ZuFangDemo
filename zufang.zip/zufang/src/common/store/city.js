import { createSlice } from "@reduxjs/toolkit";

let cityName = localStorage.getItem('cityname') || '上海'

const citySlice = createSlice({
    name: 'city',
    initialState: {
        cityName
    },
    reducers: {
        change:(state, action) => {
            state.cityName = action.payload
            localStorage.setItem("cityname", action.payload)
        },
        deleteCity:state => {
            state.cityName = ""
        }
    }
})

export const {change, deleteCity} = citySlice.actions

export default citySlice.reducer