

import './Nav.css'
import "../assets/css/iconfont.css"
import { useNavigate } from 'react-router-dom'

const Nav = (prop) => {
    let nav = useNavigate()
    function goBack() {
        
        nav(-1)
    }

    return (
        <div className='nav'>
            <span onClick={goBack} className='iconfont icon-fanhui back'></span>
            <div className='title'>{prop.children}</div>
        </div>
    )

}

export default Nav