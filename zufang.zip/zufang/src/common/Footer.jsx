
import { TabBar } from "antd-mobile"
import { useEffect, useState } from "react"
import { useLocation, useNavigate } from "react-router-dom"
import './Footer.css'
import {
    AppOutline,
    MessageOutline,
    MessageFill,
    UserOutline,
  } from 'antd-mobile-icons'

export default function Footer() {

    const navigate = useNavigate()

    const [active, setActive] = useState('/')
    const location = useLocation()
    useEffect(() => {
        
        setActive(location.pathname)
    },[location])


    const onChangeAction = (key) => {

        setActive(key)
        navigate(key)
    }

    return (
        <div className="footer">
            <TabBar onChange={onChangeAction} activeKey={active}>
                <TabBar.Item title='首页' key='/' icon={AppOutline}>

                </TabBar.Item >
                <TabBar.Item  title='商城' key='/shop' icon={MessageOutline}>

                </TabBar.Item >
                <TabBar.Item  title='生活服务' key='/life' icon={MessageFill}>

                </TabBar.Item >
                <TabBar.Item  title='我的' key='/about' icon={UserOutline} >

                </TabBar.Item >
            </TabBar>
        </div>
    )
}