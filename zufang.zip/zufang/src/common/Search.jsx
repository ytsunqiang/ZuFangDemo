import './Search.css'
import { useEffect, useState, useRef } from 'react';
import PropTypes from 'prop-types'


const Search = (prop) => {

    const [value, setValue] = useState("")
    const ref = useRef()
    useEffect(()=>{
        ref.current.focus()
    }, [])

    function valueChange(e) {
        
        setValue(e.target.value)
    }

    function keyUp(e) {
        prop.onKeyUp(value, e.keyCode)
    }

    return (
        <input ref={ref} value={value} onChange={valueChange} onKeyUp={keyUp} type='text' className="search"></input>
    )
}

Search.propTypes = {
    onKeyUp: PropTypes.func.isRequired
}


export default Search;